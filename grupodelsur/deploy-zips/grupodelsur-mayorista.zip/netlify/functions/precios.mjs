import { getStore } from '@netlify/blobs';

// Precios iniciales (semilla). La verdad viva se guarda en Netlify Blobs.
const SEED = {
  "negocio": "Grupo Cementera del Sur",
  "actualizado": "2026-08-15",
  "productos": [
    {
      "id": "001",
      "cat": "Cementos y Bases",
      "cod": "36892",
      "nom": "Cemento Loma Negra",
      "sub": "Bolsa x 50kg",
      "min": 6943,
      "may": 5950
    },
    {
      "id": "002",
      "cat": "Cementos y Bases",
      "cod": "36923",
      "nom": "Cemento Holcim",
      "sub": "Bolsa x 50kg",
      "min": 5500,
      "may": 4670
    },
    {
      "id": "003",
      "cat": "Cementos y Bases",
      "cod": "2232364",
      "nom": "Pallet Cemento Holcim",
      "sub": "Completo",
      "min": 49680,
      "may": 36988
    },
    {
      "id": "004",
      "cat": "Cementos y Bases",
      "cod": "37257",
      "nom": "Cal Cacique Max",
      "sub": "",
      "min": 7221,
      "may": 5650
    },
    {
      "id": "005",
      "cat": "Cementos y Bases",
      "cod": "37987",
      "nom": "Cal Milagro",
      "sub": "",
      "min": 16020,
      "may": 14685
    },
    {
      "id": "006",
      "cat": "Cementos y Bases",
      "cod": "38718",
      "nom": "Fino a la Cal",
      "sub": "",
      "min": 12980,
      "may": 9900
    },
    {
      "id": "007",
      "cat": "Cementos y Bases",
      "cod": "38353",
      "nom": "Plasticor",
      "sub": "",
      "min": 6097,
      "may": 5150
    },
    {
      "id": "008",
      "cat": "Cementos y Bases",
      "cod": "—",
      "nom": "Cemento Blanco",
      "sub": "x 1 kg",
      "min": 2849,
      "may": 2121
    },
    {
      "id": "009",
      "cat": "Cementos y Bases",
      "cod": "9002.15",
      "nom": "Yeso Tradicional",
      "sub": "",
      "min": 17333,
      "may": 13816
    },
    {
      "id": "010",
      "cat": "Pegamentos",
      "cod": "767377",
      "nom": "Pegamento Cerámica Hornero",
      "sub": "",
      "min": 11420,
      "may": 8720
    },
    {
      "id": "011",
      "cat": "Pegamentos",
      "cod": "767742",
      "nom": "Pegamento Porcelanato Hornero",
      "sub": "",
      "min": 19190,
      "may": 14650
    },
    {
      "id": "012",
      "cat": "Pegamentos",
      "cod": "9001.57",
      "nom": "Peg. Cerámico Klaukol",
      "sub": "x 25 kg",
      "min": 14807,
      "may": 11024
    },
    {
      "id": "013",
      "cat": "Pegamentos",
      "cod": "9001.59",
      "nom": "Peg. Porcelanato Klaukol",
      "sub": "x 25 kg",
      "min": 25088,
      "may": 18679
    },
    {
      "id": "014",
      "cat": "Pegamentos",
      "cod": "—",
      "nom": "Peg. Porcelanato Holcim",
      "sub": "x 25 kg",
      "min": 15823,
      "may": 11781
    },
    {
      "id": "015",
      "cat": "Pegamentos",
      "cod": "—",
      "nom": "2 en 1 Mapei",
      "sub": "entodo proyect.",
      "min": 8329,
      "may": 6980
    },
    {
      "id": "016",
      "cat": "Pegamentos",
      "cod": "46032",
      "nom": "Pastinas",
      "sub": "x 1 kg",
      "min": 2340,
      "may": 1790
    },
    {
      "id": "019",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132619",
      "nom": "Hidrófugo",
      "sub": "x 1 lt",
      "min": 3180,
      "may": 2430
    },
    {
      "id": "020",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132650",
      "nom": "Hidrófugo",
      "sub": "x 4 lt",
      "min": 8090,
      "may": 6180
    },
    {
      "id": "021",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132678",
      "nom": "Hidrófugo",
      "sub": "x 10 lt",
      "min": 13920,
      "may": 10620
    },
    {
      "id": "022",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132709",
      "nom": "Hidrófugo",
      "sub": "x 24 lt",
      "min": 27830,
      "may": 21240
    },
    {
      "id": "023",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132739",
      "nom": "Hidrófugo Hornero",
      "sub": "x 220 lt",
      "min": 171870,
      "may": 131160
    },
    {
      "id": "024",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1132984",
      "nom": "Ligante",
      "sub": "x 1 lt",
      "min": 7890,
      "may": 6020
    },
    {
      "id": "025",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1133015",
      "nom": "Ligante",
      "sub": "x 4 lt",
      "min": 29250,
      "may": 22320
    },
    {
      "id": "026",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1133043",
      "nom": "Ligante",
      "sub": "x 10 lt",
      "min": 56550,
      "may": 43160
    },
    {
      "id": "027",
      "cat": "Hidrófugos y Ligantes",
      "cod": "1133074",
      "nom": "Ligante",
      "sub": "x 20 lt",
      "min": 111590,
      "may": 85160
    },
    {
      "id": "028",
      "cat": "Hidrófugos y Ligantes",
      "cod": "—",
      "nom": "Acelerante de Frague",
      "sub": "x 1 kg",
      "min": 3955,
      "may": 2945
    },
    {
      "id": "029",
      "cat": "Membranas",
      "cod": "10000.93",
      "nom": "Membrana 4mm Aquastop",
      "sub": "",
      "min": 40700,
      "may": 32500
    },
    {
      "id": "030",
      "cat": "Membranas",
      "cod": "9000.70",
      "nom": "Asfáltico",
      "sub": "x 18 lt",
      "min": 48300,
      "may": 38600
    },
    {
      "id": "031",
      "cat": "Hierros y Mallas",
      "cod": "9002.23",
      "nom": "Hierro Dulce 4,2",
      "sub": "x kg",
      "min": 4844,
      "may": 3861
    },
    {
      "id": "032",
      "cat": "Hierros y Mallas",
      "cod": "9002.24",
      "nom": "Hierro Dulce 6",
      "sub": "x kg",
      "min": 4844,
      "may": 3861
    },
    {
      "id": "033",
      "cat": "Hierros y Mallas",
      "cod": "2594227",
      "nom": "Varilla Hierro 4,2 mm",
      "sub": "",
      "min": 2959,
      "may": 2358
    },
    {
      "id": "034",
      "cat": "Hierros y Mallas",
      "cod": "1863104",
      "nom": "Varilla Hierro 6 mm",
      "sub": "",
      "min": 6256,
      "may": 5376
    },
    {
      "id": "035",
      "cat": "Hierros y Mallas",
      "cod": "1863469",
      "nom": "Varilla Hierro 8 mm",
      "sub": "",
      "min": 10626,
      "may": 9132
    },
    {
      "id": "036",
      "cat": "Hierros y Mallas",
      "cod": "1863834",
      "nom": "Varilla Hierro 10 mm",
      "sub": "",
      "min": 16589,
      "may": 14256
    },
    {
      "id": "037",
      "cat": "Hierros y Mallas",
      "cod": "1864199",
      "nom": "Varilla Hierro 12 mm",
      "sub": "",
      "min": 23768,
      "may": 20426
    },
    {
      "id": "038",
      "cat": "Hierros y Mallas",
      "cod": "1864565",
      "nom": "Varilla Hierro 16 mm",
      "sub": "",
      "min": 41600,
      "may": 35750
    },
    {
      "id": "039",
      "cat": "Hierros y Mallas",
      "cod": "1864930",
      "nom": "Varilla Hierro 20 mm",
      "sub": "",
      "min": 64968,
      "may": 55832
    },
    {
      "id": "040",
      "cat": "Hierros y Mallas",
      "cod": "1865295",
      "nom": "Varilla Hierro 25 mm",
      "sub": "",
      "min": 101368,
      "may": 87113
    },
    {
      "id": "041",
      "cat": "Hierros y Mallas",
      "cod": "9002.21",
      "nom": "Mallas 4 15×25",
      "sub": "",
      "min": 19714,
      "may": 16942
    },
    {
      "id": "042",
      "cat": "Hierros y Mallas",
      "cod": "9002.13",
      "nom": "Mallas 6 15×25",
      "sub": "",
      "min": 36700,
      "may": 31600
    },
    {
      "id": "043",
      "cat": "Hierros y Mallas",
      "cod": "9002.22",
      "nom": "Mallas 6 15×15",
      "sub": "",
      "min": 57008,
      "may": 48991
    },
    {
      "id": "044",
      "cat": "Hierros y Mallas",
      "cod": "9002.25",
      "nom": "Metal Desplegable",
      "sub": "",
      "min": 7535,
      "may": 6006
    },
    {
      "id": "045",
      "cat": "Hierros y Mallas",
      "cod": "9001.62",
      "nom": "Clavos 2″",
      "sub": "x kg",
      "min": 4871,
      "may": 3756
    },
    {
      "id": "046",
      "cat": "Hierros y Mallas",
      "cod": "9001.63",
      "nom": "Clavos 2½″",
      "sub": "x kg",
      "min": 4712,
      "may": "Consultá"
    },
    {
      "id": "047",
      "cat": "Hierros y Mallas",
      "cod": "—",
      "nom": "Clavos 4″",
      "sub": "x kg",
      "min": "Consultá",
      "may": "Consultá"
    },
    {
      "id": "048",
      "cat": "Hierros y Mallas",
      "cod": "—",
      "nom": "Alambre",
      "sub": "x kg",
      "min": 5410,
      "may": 4312
    },
    {
      "id": "049",
      "cat": "Armalogic Columnas",
      "cod": "9002.16",
      "nom": "Armalogic Columna 10×10",
      "sub": "",
      "min": 15055,
      "may": 14401
    },
    {
      "id": "050",
      "cat": "Armalogic Columnas",
      "cod": "9002.17",
      "nom": "Armalogic Columna 12×12",
      "sub": "",
      "min": 15472,
      "may": 14799
    },
    {
      "id": "051",
      "cat": "Armalogic Columnas",
      "cod": "9002.18",
      "nom": "Armalogic Columna 10×15",
      "sub": "",
      "min": 15602,
      "may": 14924
    },
    {
      "id": "052",
      "cat": "Armalogic Columnas",
      "cod": "9002.19",
      "nom": "Armalogic Columna 15×15",
      "sub": "",
      "min": 16175,
      "may": 15472
    },
    {
      "id": "053",
      "cat": "Armalogic Columnas",
      "cod": "9002.20",
      "nom": "Armalogic Columna 20×20",
      "sub": "",
      "min": 17425,
      "may": 16668
    },
    {
      "id": "054",
      "cat": "Ladrillos",
      "cod": "402499",
      "nom": "Ladrillo Hueco 8",
      "sub": "x unidad",
      "min": 595,
      "may": 475
    },
    {
      "id": "055",
      "cat": "Ladrillos",
      "cod": "402165",
      "nom": "Ladrillo Hueco 12",
      "sub": "x unidad",
      "min": 735,
      "may": 600
    },
    {
      "id": "056",
      "cat": "Ladrillos",
      "cod": "—",
      "nom": "Ladrillo Hueco 18",
      "sub": "x unidad",
      "min": 1040,
      "may": 840
    },
    {
      "id": "057",
      "cat": "Ladrillos",
      "cod": "2594288",
      "nom": "Ladrillo Común",
      "sub": "x unidad",
      "min": 228,
      "may": 193
    },
    {
      "id": "058",
      "cat": "Ladrillos",
      "cod": "9002.31",
      "nom": "Ladrillo Mendoza 1era",
      "sub": "x unidad",
      "min": 247,
      "may": 209
    },
    {
      "id": "059",
      "cat": "Ladrillos",
      "cod": "9002.30",
      "nom": "Ladrillo Mendoza 2da",
      "sub": "x unidad",
      "min": 325,
      "may": 275
    },
    {
      "id": "060",
      "cat": "Ladrillos",
      "cod": "402864",
      "nom": "Ladrillo Portante 12×19×33",
      "sub": "x unidad",
      "min": 1234,
      "may": 1131
    },
    {
      "id": "061",
      "cat": "Ladrillos",
      "cod": "402895",
      "nom": "Ladrillo Portante 12×24×33",
      "sub": "x unidad",
      "min": 1440,
      "may": 1320
    },
    {
      "id": "062",
      "cat": "Ladrillos",
      "cod": "402923",
      "nom": "Ladrillo Portante 18×19×33",
      "sub": "x unidad",
      "min": 1298,
      "may": 1190
    },
    {
      "id": "063",
      "cat": "Ladrillos",
      "cod": "402954",
      "nom": "Ladrillo Portante 18×25×33",
      "sub": "x unidad",
      "min": 1380,
      "may": 1265
    },
    {
      "id": "064",
      "cat": "Bloques",
      "cod": "403229",
      "nom": "Bloque Liso 20",
      "sub": "",
      "min": 2570,
      "may": 2048
    },
    {
      "id": "065",
      "cat": "Bloques",
      "cod": "403260",
      "nom": "Bloque Liso 13",
      "sub": "",
      "min": 1811,
      "may": 1443
    },
    {
      "id": "066",
      "cat": "Bloques",
      "cod": "403289",
      "nom": "Bloque Esplitado 20×20×40",
      "sub": "",
      "min": 4430,
      "may": 3531
    },
    {
      "id": "067",
      "cat": "Bloques",
      "cod": "403320",
      "nom": "Bloque Esplitado 13",
      "sub": "",
      "min": 3853,
      "may": 3071
    },
    {
      "id": "068",
      "cat": "Áridos y Graneles",
      "cod": "1001.01",
      "nom": "Arena",
      "sub": "x m³",
      "min": 37000,
      "may": 28000
    },
    {
      "id": "069",
      "cat": "Áridos y Graneles",
      "cod": "9001.58",
      "nom": "Arena",
      "sub": "x bolsón",
      "min": 45600,
      "may": "Consultá"
    },
    {
      "id": "070",
      "cat": "Áridos y Graneles",
      "cod": "10000.56",
      "nom": "Arena",
      "sub": "x ½ bolsón",
      "min": 26000,
      "may": "Consultá"
    },
    {
      "id": "071",
      "cat": "Áridos y Graneles",
      "cod": "1003.01",
      "nom": "Piedra",
      "sub": "x m³",
      "min": 72900,
      "may": 66700
    },
    {
      "id": "072",
      "cat": "Áridos y Graneles",
      "cod": "9001.61",
      "nom": "Piedra",
      "sub": "x bolsón",
      "min": 81500,
      "may": "Consultá"
    },
    {
      "id": "073",
      "cat": "Áridos y Graneles",
      "cod": "—",
      "nom": "Piedra",
      "sub": "x ½ bolsón",
      "min": 46500,
      "may": "Consultá"
    },
    {
      "id": "074",
      "cat": "Áridos y Graneles",
      "cod": "1002.01",
      "nom": "Cascote",
      "sub": "x m³",
      "min": 23595,
      "may": 19100
    },
    {
      "id": "075",
      "cat": "Áridos y Graneles",
      "cod": "9002.32",
      "nom": "Cascote",
      "sub": "x bolsón",
      "min": 32195,
      "may": "Consultá"
    },
    {
      "id": "076",
      "cat": "Áridos y Graneles",
      "cod": "2228347",
      "nom": "Bolsones Vacíos",
      "sub": "",
      "min": 8600,
      "may": 8600
    },
    {
      "id": "077",
      "cat": "Áridos y Graneles",
      "cod": "2228378",
      "nom": "Bolsón ½",
      "sub": "",
      "min": 6600,
      "may": 6600
    },
    {
      "id": "078",
      "cat": "Aislantes y Varios",
      "cod": "9002.34",
      "nom": "Block Tergopol 10 cm",
      "sub": "x equipo",
      "min": 4200,
      "may": 3500
    },
    {
      "id": "079",
      "cat": "Aislantes y Varios",
      "cod": "9002.35",
      "nom": "Block Tergopol 12 cm",
      "sub": "x equipo",
      "min": 4800,
      "may": 4400
    },
    {
      "id": "080",
      "cat": "Aislantes y Varios",
      "cod": "9001.72",
      "nom": "Isocret",
      "sub": "x 170 lt",
      "min": 37800,
      "may": 27700
    },
    {
      "id": "081",
      "cat": "Aluminio",
      "cod": "10000.15",
      "nom": "Regla Aluminio 75×25",
      "sub": "x 3 mts",
      "min": 49900,
      "may": 39000
    },
    {
      "id": "082",
      "cat": "Aluminio",
      "cod": "10000.16",
      "nom": "Regla Aluminio 75×25",
      "sub": "x 2 mts",
      "min": 33300,
      "may": 26000
    }
  ]
};

const getPin = () => process.env.PRECIOS_PIN || '1234';

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store',
      'access-control-allow-origin': '*'
    }
  });
}

export default async (req) => {
  try {
    const store = getStore('precios');
    if (req.method === 'GET') {
      const data = await store.get('data', { type: 'json' });
      return json(data || SEED);
    }
    if (req.method === 'POST') {
      let body = {};
      try { body = await req.json(); } catch (_) {}
      if (body.accion === 'verificar') return json(body.pin === getPin());
      if (body.accion === 'guardar') {
        if (body.pin !== getPin()) return json({ error: 'PIN incorrecto' }, 403);
        if (!body.data || !Array.isArray(body.data.productos)) return json({ error: 'datos invalidos' }, 400);
        await store.setJSON('data', body.data);
        return json({ ok: true });
      }
      return json({ error: 'accion desconocida' }, 400);
    }
    return json({ error: 'metodo no permitido' }, 405);
  } catch (e) {
    return json({ error: String((e && e.message) || e) }, 500);
  }
};

export const config = { path: '/api/precios' };
